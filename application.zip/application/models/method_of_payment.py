from typing import List
from typing import Optional
from sqlalchemy.orm import mapped_column, Mapped, relationship
from sqlalchemy import Integer, VARCHAR, ForeignKey
from models import Base, Billing

class MethodOfPayment(Base):
    __tablename__ = "method_of_payment"

    id: Mapped[int] = mapped_column("id", Integer, primary_key=True, autoincrement=True, nullable=False)
    name: Mapped[str] = mapped_column("name", VARCHAR(45), nullable=False)
    description: Mapped[int] = mapped_column("description", VARCHAR(256), nullable=False)

    billing_id: Mapped[int] = mapped_column("billing_id", Integer, ForeignKey("billing.id"), nullable=False)

    billing: Mapped[List["Billing"]] = relationship(backref="methodOfPayment")
