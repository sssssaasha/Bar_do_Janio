from typing import List
from typing import Optional
from sqlalchemy.orm import mapped_column, Mapped, relationship
from sqlalchemy import Integer, VARCHAR
from models import Base, Employee

class Role(Base):
    __tablename__ = "role"

    id: Mapped[int] = mapped_column("id", Integer, primary_key=True, autoincrement=True, nullable=False)
    description: Mapped[str] = mapped_column("description", VARCHAR(256), nullable=False)
    name: Mapped[str] = mapped_column("name", VARCHAR(45), nullable=False)

    employee: Mapped[List["Employee"]] = relationship(backref="role")
