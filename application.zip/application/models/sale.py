from typing import List
from typing import Optional
from sqlalchemy.orm import mapped_column, Mapped, relationship
from sqlalchemy import Integer, Date, DateTime, ForeignKey
from models import Base, Billing, Order, Customer, Employee

class Sale(Base):
    __tablename__ = "Sale"

    id: Mapped[int] = mapped_column("id", Integer, primary_key=True, autoincrement=True, nullable=False)
    date: Mapped[int] = mapped_column("date", Date, nullable=False)
    creation_date: Mapped[int] = mapped_column("creation_date", DateTime, nullable=False)

    customer_id: Mapped[int] = mapped_column("customer_id", Integer, ForeignKey("customer.id"), nullable=False)
    billing_id: Mapped[int] = mapped_column("billing_id", Integer, ForeignKey("billing.id"), nullable=False)
    employee_id: Mapped[int] = mapped_column("employee_id", Integer, ForeignKey("employee.id"), nullable=False)

    billing: Mapped[List["Billing"]] = relationship(backref="sale")
    order: Mapped[List["Order"]] = relationship(backref="sale")
    customer: Mapped[List["Customer"]] = relationship(backref="sale") 
    employee: Mapped[List["Employee"]] = relationship(backref="sale")

