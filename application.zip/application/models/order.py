from models import Base
from typing import List
from typing import Optional
from sqlalchemy.orm import mapped_column, Mapped, relationship
from sqlalchemy import Integer, DECIMAL, ForeignKey
from models import Base, Product, Employee, Sale

class Order(Base):
    __tablename__ = "Order"
    id: Mapped[int] = mapped_column("id", Integer, primary_key=True, autoincrement=True, nullable=False)
    quantity: Mapped[int] = mapped_column("quantity", Integer, nullable=False)
    value: Mapped[float] = mapped_column("value", DECIMAL(10, 2), nullable=False)

    employee_id: Mapped[int] = mapped_column("employee_id", Integer, ForeignKey("employee.id"), nullable=False)
    sale_id: Mapped[int] = mapped_column("sale_id", Integer, ForeignKey("sale.id"), nullable=False)

    product: Mapped[List["Product"]] = relationship(backref="order")
    employee: Mapped[List["Employee"]] = relationship(backref="order")
    sale: Mapped[List["Sale"]] = relationship(backref="order")


