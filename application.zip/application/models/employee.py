from typing import List
from typing import Optional
from sqlalchemy.orm import mapped_column, Mapped, relationship
from sqlalchemy import Integer, Float, ForeignKey
from models import Base, Role, Payment, Order, Sale, Person

class Employee(Base):
    __tablename__ = "employee"
    id: Mapped[int] = mapped_column("id", Integer, primary_key=True, autoincrement=True, nullable=False)
    salary: Mapped[float] = mapped_column("salary", Float, nullable=False)

    role_id: Mapped[int] = mapped_column("role_id", Integer, ForeignKey("role.id"), nullable=False)

    role: Mapped[List["Role"]] = relationship(backref="employee")
    payment: Mapped[List["Payment"]] = relationship(backref="employee")
    order: Mapped[List["Order"]] = relationship(backref="employee")
    sale: Mapped[List["Sale"]] = relationship(backref="employee")
    person: Mapped[List["Person"]] = relationship(backref="employee")



