from typing import List
from typing import Optional
from sqlalchemy.orm import mapped_column, Mapped, relationship
from sqlalchemy import Integer, DECIMAL, Date, ForeignKey
from models import Base, MethodOfPayment, Sale

class Billing(Base):
    __tablename__ = "billing"
    id: Mapped[int] = mapped_column("id", Integer, primary_key=True, autoincrement=True, nullable=False)
    value: Mapped[float] = mapped_column("value", DECIMAL(10, 2), nullable=False)
    date: Mapped[int] = mapped_column("date", Date, nullable=False)
    status: Mapped[int] = mapped_column("status", Integer(1), nullable=False)

    methodOfPayment_id: Mapped[int] = mapped_column("methodOfPayment_id", Integer, ForeignKey("methodOfPayment.id"), nullable=False)

    methodOfPayment: Mapped[List["MethodOfPayment"]] = relationship(backref="billing") 
    sale: Mapped[List["Sale"]] = relationship(backref="billing")
