from typing import List
from typing import Optional
from models import Base, Employee, Customer
from sqlalchemy.orm import mapped_column, Mapped, relationship
from sqlalchemy import Integer, VARCHAR, CHAR, ForeignKey

class Person(Base):
    __tablename__ = "person"
    id: Mapped[int] = mapped_column("id", Integer(), primary_key=True, autoincrement=True, nullable=False)
    cpf: Mapped[str] = mapped_column("cpf", CHAR(11), unique=True, nullable=False)
    rg: Mapped[str] = mapped_column("rg", VARCHAR(11), nullable=False)
    name: Mapped[str] = mapped_column("person_name", VARCHAR(256), nullable=False)

    customer_id: Mapped[int] = mapped_column("customer_id", Integer, ForeignKey("customer.id"), nullable=False)
    employee_id: Mapped[int] = mapped_column("employee_id", Integer, ForeignKey("employee.id"), nullable=False)

    employee: Mapped[List["Employee"]] = relationship(backref="person")
    customer: Mapped[List["Customer"]] = relationship(backref="person")
