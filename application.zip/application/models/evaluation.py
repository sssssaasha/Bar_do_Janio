from models import Base, Customer
from typing import List
from typing import Optional
from sqlalchemy.orm import mapped_column, Mapped, relationship
from sqlalchemy import Integer, VARCHAR, Date, ForeignKey

class Evaluation(Base):
    __tablename__ = "evaluation"
    id: Mapped[int] = mapped_column("id", Integer, primary_key=True, autoincrement=True, nullable=False)
    comment: Mapped[str] = mapped_column("comment", VARCHAR(100), nullable=True)
    rating: Mapped[int] = mapped_column("rating", Integer(5), nullable=False)
    date: Mapped[int] = mapped_column("date", Date, nullable=False)

    customer_id: Mapped[int] = mapped_column("customer_id", Integer, ForeignKey("customer.id"), nullable=False)
    bar_id: Mapped[int] = mapped_column("bar_id", Integer, ForeignKey("bar.id"), nullable=False)

    customer: Mapped[List["Customer"]] = relationship(backref="evaluation")

    
