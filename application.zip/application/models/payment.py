from typing import List
from typing import Optional
from sqlalchemy.orm import mapped_column, Mapped, relationship
from sqlalchemy import Integer, DECIMAL, VARCHAR, ForeignKey
from models import Base, Employee

class Payment(Base):
    __tablename__ = "payment"

    id: Mapped[int] = mapped_column("id", Integer, primary_key=True, autoincrement=True, nullable=False)
    value: Mapped[float] = mapped_column("value", DECIMAL(10, 2), nullable=False)
    description: Mapped[str] = mapped_column("description", VARCHAR(256), nullable=False)
    name: Mapped[str] = mapped_column("name", VARCHAR(45), nullable=False)

    employee_id: Mapped[int] = mapped_column("employee_id", Integer, ForeignKey("employee.id"), nullable=False)

    employee: Mapped[List["Employee"]] = relationship(backref="payment")
