from typing import List
from typing import Optional
from models import Base, Person, Sale
from sqlalchemy.orm import mapped_column, Mapped, relationship
from sqlalchemy import Integer, VARCHAR, CHAR
from sqlalchemy import ForeignKey

class Customer(Base):
    __tablename__ = "customer"
    id: Mapped[int] = mapped_column("id", Integer(), primary_key=True, autoincrement=True, nullable=False)
    order_ammount: Mapped[int] = mapped_column("orderAmmount", Integer(), nullable=False)
    person_id = Mapped[int] = mapped_column(ForeignKey("person.id"))

    person: Mapped[List["Person"]] = relationship(backref="customer")
    sale: Mapped[List["Sale"]] = relationship(backref="costumer")

