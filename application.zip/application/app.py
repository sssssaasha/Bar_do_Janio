from utils.create_db import create_db

if __name__ == '__main__':
    create_db()
